export const googleLoginURL = 'https://real-estate-crm-api.onrender.com/api/auth/google';


